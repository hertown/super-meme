import React from 'react';
import { Header } from './components/Layout/Header';
import { AuthContainer } from './components/Auth/AuthContainer';
import { DashboardView } from './views/DashboardView';
import { ProblemsView } from './views/ProblemsView';
import { useAuth } from './hooks/useAuth';
import { useFirebase } from './hooks/useFirebase';
import { LoadingSpinner } from './components/common/LoadingSpinner';

export function App() {
  const { user, loading: authLoading, login, register, logout } = useAuth();
  const { loading: dataLoading, error } = useFirebase();
  const [currentPage, setCurrentPage] = React.useState<'incidents' | 'problems'>('incidents');

  if (authLoading || dataLoading) {
    return <LoadingSpinner />;
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Une erreur est survenue</h2>
          <p className="text-gray-600">{error}</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <AuthContainer
        onLogin={login}
        onRegister={register}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header 
        onPageChange={setCurrentPage} 
        currentPage={currentPage}
        user={user}
        onLogout={logout}
      />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {currentPage === 'incidents' ? (
          <DashboardView />
        ) : (
          <ProblemsView />
        )}
      </main>
    </div>
  );
}