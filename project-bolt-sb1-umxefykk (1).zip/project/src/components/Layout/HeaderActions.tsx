import React from 'react';
import { UserMenu } from '../Auth/UserMenu';
import { ImportMenu } from './ImportMenu';
import { User } from '../../types/auth';

interface HeaderActionsProps {
  user: User;
  onLogout: () => void;
}

export function HeaderActions({ user, onLogout }: HeaderActionsProps) {
  return (
    <div className="flex items-center space-x-4">
      <ImportMenu />
      <UserMenu user={user} onLogout={onLogout} />
    </div>
  );
}