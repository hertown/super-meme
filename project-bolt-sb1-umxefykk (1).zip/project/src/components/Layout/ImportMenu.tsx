import React, { useState } from 'react';
import { Upload, Database, FileSpreadsheet, ChevronDown } from 'lucide-react';
import { Button } from '../common/Button/Button';

export function ImportMenu() {
  const [showMenu, setShowMenu] = useState(false);

  const handleImport = (type: 'excel' | 'itsm' | 'database') => {
    switch (type) {
      case 'excel':
        // Trigger file input click
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = '.xlsx,.xls,.csv';
        input.onchange = (e) => {
          const file = (e.target as HTMLInputElement).files?.[0];
          if (file) {
            console.log('Importing Excel file:', file);
            // Handle Excel import
          }
        };
        input.click();
        break;
      case 'itsm':
        console.log('Opening ITSM connection dialog');
        // Handle ITSM import
        break;
      case 'database':
        console.log('Opening database connection dialog');
        // Handle database import
        break;
    }
    setShowMenu(false);
  };

  return (
    <div className="relative">
      <Button
        variant="outline"
        size="sm"
        onClick={() => setShowMenu(!showMenu)}
        className="flex items-center"
      >
        <Upload className="w-4 h-4 mr-2" />
        Importer
        <ChevronDown className="w-4 h-4 ml-2" />
      </Button>

      {showMenu && (
        <div className="absolute right-0 mt-2 w-56 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 z-50">
          <div className="py-1" role="menu">
            <button
              onClick={() => handleImport('excel')}
              className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
            >
              <FileSpreadsheet className="w-4 h-4 mr-2" />
              Fichier Excel/CSV
            </button>
            <button
              onClick={() => handleImport('itsm')}
              className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
            >
              <Upload className="w-4 h-4 mr-2" />
              Connexion ITSM
            </button>
            <button
              onClick={() => handleImport('database')}
              className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
            >
              <Database className="w-4 h-4 mr-2" />
              Base de données
            </button>
          </div>
        </div>
      )}
    </div>
  );
}