import React from 'react';
import { Activity } from 'lucide-react';

export function HeaderTitle() {
  return (
    <div className="flex items-center space-x-3">
      <Activity className="w-8 h-8 text-blue-600" />
      <div>
        <h1 className="text-2xl font-bold text-gray-900">
          ITSM Analytics
        </h1>
        <p className="text-sm text-gray-500">
          Gestion intelligente de vos services IT
        </p>
      </div>
    </div>
  );
}