import React from 'react';
import { HeaderTitle } from './HeaderTitle';
import { HeaderActions } from './HeaderActions';
import { HeaderFilters } from './HeaderFilters';
import { User } from '../../types/auth';

interface HeaderProps {
  onPageChange: (page: 'incidents' | 'problems') => void;
  currentPage: 'incidents' | 'problems';
  user: User;
  onLogout: () => void;
}

export function Header({ onPageChange, currentPage, user, onLogout }: HeaderProps) {
  return (
    <header className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-start py-4">
          <HeaderTitle />
          <HeaderActions user={user} onLogout={onLogout} />
        </div>
        <HeaderFilters 
          currentPage={currentPage}
          onPageChange={onPageChange}
        />
      </div>
    </header>
  );
}