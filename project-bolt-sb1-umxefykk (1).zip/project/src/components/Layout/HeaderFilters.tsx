import React from 'react';
import { Search } from 'lucide-react';
import { Button } from '../common/Button/Button';
import { FilterSelect } from './FilterSelect';
import { useFilters } from '../../hooks/useFilters';

interface HeaderFiltersProps {
  currentPage: 'incidents' | 'problems';
  onPageChange: (page: 'incidents' | 'problems') => void;
}

export function HeaderFilters({ currentPage, onPageChange }: HeaderFiltersProps) {
  const { filters, updateFilter } = useFilters();

  return (
    <div className="flex items-center space-x-4 py-4 overflow-x-auto">
      <Button
        variant={currentPage === 'incidents' ? 'primary' : 'outline'}
        size="sm"
        onClick={() => onPageChange('incidents')}
      >
        Incidents
      </Button>
      <Button
        variant={currentPage === 'problems' ? 'primary' : 'outline'}
        size="sm"
        onClick={() => onPageChange('problems')}
      >
        Problèmes
      </Button>
      
      <FilterSelect
        options={[
          { value: 'all', label: 'Toutes les catégories' },
          { value: 'infrastructure', label: 'Infrastructure' },
          { value: 'application', label: 'Applications' },
          { value: 'network', label: 'Réseau' },
          { value: 'security', label: 'Sécurité' },
          { value: 'database', label: 'Base de données' }
        ]}
        value={filters.category}
        onChange={(value) => updateFilter('category', value)}
        className="w-44"
      />
      
      <div className="relative flex-1">
        <input
          type="search"
          placeholder="Rechercher..."
          className="w-full pl-10 pr-4 py-2 rounded-md border-gray-300 focus:border-blue-500 focus:ring-blue-500"
        />
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
      </div>
    </div>
  );
}