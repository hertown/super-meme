import React, { useState } from 'react';
import { LoginForm } from './LoginForm';
import { RegisterForm } from './RegisterForm';
import { UserRole } from '../../types/auth';
import { AuthBranding } from './AuthBranding';
import { LanguageSelector } from '../common/LanguageSelector/LanguageSelector';
import { useLanguage } from '../../hooks/useLanguage';

interface AuthContainerProps {
  onLogin: (email: string, password: string) => void;
  onRegister: (userData: {
    email: string;
    password: string;
    name: string;
    role: UserRole;
    organization: string;
  }) => void;
}

export function AuthContainer({ onLogin, onRegister }: AuthContainerProps) {
  const [showLogin, setShowLogin] = useState(true);
  const { language, setLanguage, t } = useLanguage();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50">
      <LanguageSelector 
        currentLanguage={language}
        onLanguageChange={setLanguage}
      />
      <div className="flex min-h-screen">
        <AuthBranding />

        <div className="w-full lg:w-1/2 flex items-center justify-center p-8">
          <div className="w-full max-w-md">
            <div className="text-center lg:text-left mb-8">
              <h2 className="text-2xl font-bold text-gray-900">
                {showLogin ? t('welcome') : t('register.title')}
              </h2>
              <p className="mt-2 text-sm text-gray-600">
                {showLogin ? t('login.subtitle') : t('register.subtitle')}
              </p>
            </div>

            <div className="bg-white shadow-xl rounded-lg p-8">
              {showLogin ? (
                <LoginForm 
                  onLogin={onLogin} 
                  onRegisterClick={() => setShowLogin(false)}
                  t={t}
                />
              ) : (
                <RegisterForm 
                  onRegister={onRegister}
                  onLoginClick={() => setShowLogin(true)}
                  t={t}
                />
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}