import React from 'react';
import { Activity, Shield } from 'lucide-react';

export function AuthBranding() {
  return (
    <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-blue-600 to-blue-800 p-12 text-white">
      <div className="max-w-lg mx-auto flex flex-col justify-center">
        <div className="flex items-center space-x-3 mb-8">
          <Activity className="w-10 h-10" />
          <Shield className="w-10 h-10" />
        </div>
        <h1 className="text-4xl font-bold mb-4">ITSM Analytics</h1>
        <h2 className="text-2xl font-semibold mb-8">Gestion intelligente de vos services IT</h2>
        <p className="text-lg mb-6">
          Plateforme de gestion centralisée pour vos incidents et problèmes IT
        </p>
        <ul className="space-y-4 text-blue-100">
          <li className="flex items-center">
            <span className="w-2 h-2 bg-blue-200 rounded-full mr-3"></span>
            Suivi en temps réel des incidents
          </li>
          <li className="flex items-center">
            <span className="w-2 h-2 bg-blue-200 rounded-full mr-3"></span>
            Analyse approfondie des problèmes
          </li>
          <li className="flex items-center">
            <span className="w-2 h-2 bg-blue-200 rounded-full mr-3"></span>
            Tableaux de bord personnalisables
          </li>
          <li className="flex items-center">
            <span className="w-2 h-2 bg-blue-200 rounded-full mr-3"></span>
            Rapports détaillés et KPIs
          </li>
        </ul>
      </div>
    </div>
  );
}