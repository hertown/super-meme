import React from 'react';
import { IncidentStatus } from '../../types';
import { getStatusStyles } from '../../utils/statusStyles';
import Badge from './Badge';

interface StatusBadgeProps {
  status: IncidentStatus;
}

export default function StatusBadge({ status }: StatusBadgeProps) {
  return <Badge label={status} className={getStatusStyles(status)} />;
}