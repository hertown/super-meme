import React from 'react';
import { IncidentPriority } from '../../types';
import { getPriorityStyles } from '../../utils/statusStyles';
import Badge from './Badge';

interface PriorityBadgeProps {
  priority: IncidentPriority;
}

export default function PriorityBadge({ priority }: PriorityBadgeProps) {
  return <Badge label={priority} className={getPriorityStyles(priority)} />;
}