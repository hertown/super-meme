import React from 'react';
import { BarChart3, AlertCircle, CheckCircle2, Clock } from 'lucide-react';
import { mockIncidents } from '../data/mockData';

export default function Dashboard() {
  const metrics = {
    totalIncidents: mockIncidents.length,
    openIncidents: mockIncidents.filter(i => i.status === 'open').length,
    criticalIncidents: mockIncidents.filter(i => i.priority === 'critical').length,
    resolvedToday: mockIncidents.filter(i => i.status === 'resolved').length
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6">Incident Management Dashboard</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <div className="bg-white rounded-lg shadow p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-500">Total Incidents</p>
              <p className="text-2xl font-bold">{metrics.totalIncidents}</p>
            </div>
            <BarChart3 className="text-blue-500" size={24} />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-500">Open Incidents</p>
              <p className="text-2xl font-bold">{metrics.openIncidents}</p>
            </div>
            <AlertCircle className="text-yellow-500" size={24} />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-500">Critical Incidents</p>
              <p className="text-2xl font-bold">{metrics.criticalIncidents}</p>
            </div>
            <Clock className="text-red-500" size={24} />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-500">Resolved Today</p>
              <p className="text-2xl font-bold">{metrics.resolvedToday}</p>
            </div>
            <CheckCircle2 className="text-green-500" size={24} />
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow">
        <div className="p-4 border-b">
          <h2 className="text-lg font-semibold">Recent Incidents</h2>
        </div>
        <div className="p-4">
          <table className="w-full">
            <thead>
              <tr className="text-left text-gray-500">
                <th className="pb-3">ID</th>
                <th className="pb-3">Title</th>
                <th className="pb-3">Priority</th>
                <th className="pb-3">Status</th>
                <th className="pb-3">Assignee</th>
              </tr>
            </thead>
            <tbody>
              {mockIncidents.map(incident => (
                <tr key={incident.id} className="border-t">
                  <td className="py-3">{incident.id}</td>
                  <td className="py-3">{incident.title}</td>
                  <td className="py-3">
                    <span className={`px-2 py-1 rounded-full text-xs ${
                      incident.priority === 'critical' ? 'bg-red-100 text-red-800' :
                      incident.priority === 'high' ? 'bg-orange-100 text-orange-800' :
                      'bg-blue-100 text-blue-800'
                    }`}>
                      {incident.priority}
                    </span>
                  </td>
                  <td className="py-3">
                    <span className={`px-2 py-1 rounded-full text-xs ${
                      incident.status === 'open' ? 'bg-yellow-100 text-yellow-800' :
                      incident.status === 'in-progress' ? 'bg-blue-100 text-blue-800' :
                      'bg-green-100 text-green-800'
                    }`}>
                      {incident.status}
                    </span>
                  </td>
                  <td className="py-3">{incident.assignee}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}