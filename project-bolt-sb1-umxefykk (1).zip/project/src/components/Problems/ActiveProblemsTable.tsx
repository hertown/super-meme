import React, { useState } from 'react';
import { Button } from '../common/Button/Button';
import { Badge } from '../common/Badge/Badge';
import { ChevronDown, ChevronUp, MoreVertical } from 'lucide-react';

interface Problem {
  id: string;
  description: string;
  status: string;
  impact: string;
  details: string;
}

const problems: Problem[] = [
  {
    id: 'PRB-001',
    description: 'Lenteurs application CRM',
    status: 'Investigation',
    impact: 'Critique',
    details: 'Temps de réponse > 5s sur les requêtes principales. Impact sur 200 utilisateurs.'
  },
  {
    id: 'PRB-002',
    description: 'Erreurs authentification',
    status: 'En cours',
    impact: 'Majeur',
    details: 'Échecs de connexion intermittents. Affecte les utilisateurs externes.'
  }
];

export function ActiveProblemsTable() {
  const [expandedRows, setExpandedRows] = useState<Set<string>>(new Set());
  const [hoveredRow, setHoveredRow] = useState<string | null>(null);

  const toggleRow = (id: string) => {
    const newExpanded = new Set(expandedRows);
    if (newExpanded.has(id)) {
      newExpanded.delete(id);
    } else {
      newExpanded.add(id);
    }
    setExpandedRows(newExpanded);
  };

  return (
    <div className="bg-white shadow rounded-lg overflow-hidden">
      <div className="p-4 border-b">
        <h3 className="text-lg font-semibold">Problèmes actifs</h3>
      </div>
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="w-12"></th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Description</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Statut</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Impact</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {problems.map((problem) => (
              <React.Fragment key={problem.id}>
                <tr 
                  className={`hover:bg-gray-50 transition-colors duration-150 ${
                    hoveredRow === problem.id ? 'bg-gray-50' : ''
                  }`}
                  onMouseEnter={() => setHoveredRow(problem.id)}
                  onMouseLeave={() => setHoveredRow(null)}
                >
                  <td className="px-6 py-4">
                    <button
                      onClick={() => toggleRow(problem.id)}
                      className="text-gray-400 hover:text-gray-600 transition-colors duration-150"
                    >
                      {expandedRows.has(problem.id) ? (
                        <ChevronUp className="w-5 h-5" />
                      ) : (
                        <ChevronDown className="w-5 h-5" />
                      )}
                    </button>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{problem.id}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{problem.description}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <Badge
                      label={problem.status}
                      variant={problem.status === 'Investigation' ? 'warning' : 'info'}
                    />
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <Badge
                      label={problem.impact}
                      variant={problem.impact === 'Critique' ? 'error' : 'warning'}
                    />
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex space-x-2">
                      <Button
                        variant="primary"
                        size="sm"
                        onClick={() => console.log(`Analyser problème ${problem.id}`)}
                      >
                        Analyser
                      </Button>
                      <button className="text-gray-400 hover:text-gray-600 transition-colors duration-150">
                        <MoreVertical className="w-5 h-5" />
                      </button>
                    </div>
                  </td>
                </tr>
                {expandedRows.has(problem.id) && (
                  <tr className="bg-gray-50">
                    <td colSpan={6} className="px-6 py-4">
                      <div className="animate-fade-in">
                        <h4 className="font-medium text-gray-900 mb-2">Détails du problème</h4>
                        <p className="text-gray-600">{problem.details}</p>
                      </div>
                    </td>
                  </tr>
                )}
              </React.Fragment>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}