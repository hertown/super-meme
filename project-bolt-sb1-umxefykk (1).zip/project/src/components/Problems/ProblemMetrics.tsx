import React from 'react';
import { Activity, CheckCircle2, Clock, TrendingUp } from 'lucide-react';
import { Card } from '../common/Card/Card';

const metrics = [
  {
    title: 'Problèmes actifs',
    value: '12',
    trend: '+2',
    trendType: 'up',
    icon: Activity,
    color: 'text-blue-500',
    bgColor: 'bg-blue-50'
  },
  {
    title: 'Problèmes résolus',
    value: '45',
    trend: '+5',
    trendType: 'up',
    icon: CheckCircle2,
    color: 'text-green-500',
    bgColor: 'bg-green-50'
  },
  {
    title: 'Temps moyen de résolution',
    value: '5j 4h',
    trend: '-12h',
    trendType: 'down',
    icon: Clock,
    color: 'text-orange-500',
    bgColor: 'bg-orange-50'
  },
  {
    title: 'Impact business',
    value: 'Élevé',
    trend: '+15%',
    trendType: 'up',
    icon: TrendingUp,
    color: 'text-red-500',
    bgColor: 'bg-red-50'
  }
];

export function ProblemMetrics() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {metrics.map((metric, index) => (
        <div
          key={index}
          className="opacity-0 animate-fade-in-up"
          style={{ animationDelay: `${index * 100}ms`, animationFillMode: 'forwards' }}
        >
          <Card className="relative overflow-hidden group hover:shadow-lg transition-all duration-300">
            <div className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{metric.title}</p>
                  <div className="mt-2 flex items-baseline">
                    <p className="text-3xl font-bold text-gray-900">{metric.value}</p>
                    <span className={`ml-2 text-sm font-medium ${
                      metric.trendType === 'up' ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {metric.trend}
                    </span>
                  </div>
                </div>
                <div className={`${metric.bgColor} p-3 rounded-lg transform group-hover:scale-110 transition-transform duration-300`}>
                  <metric.icon className={`w-6 h-6 ${metric.color}`} />
                </div>
              </div>
            </div>
            <div className={`absolute bottom-0 left-0 right-0 h-1 ${metric.color.replace('text', 'bg')} transform origin-left scale-x-0 group-hover:scale-x-100 transition-transform duration-300`} />
          </Card>
        </div>
      ))}
    </div>
  );
}