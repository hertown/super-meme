import React, { useState } from 'react';
import { Plus } from 'lucide-react';
import { Button } from '../../common/Button/Button';

interface TimelineEvent {
  id: string;
  date: string;
  description: string;
}

export function Timeline() {
  const [events, setEvents] = useState<TimelineEvent[]>([]);
  const [newDate, setNewDate] = useState('');
  const [newDescription, setNewDescription] = useState('');

  const handleAddEvent = () => {
    if (newDate && newDescription) {
      setEvents([
        ...events,
        {
          id: Date.now().toString(),
          date: newDate,
          description: newDescription
        }
      ]);
      setNewDate('');
      setNewDescription('');
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex gap-4">
        <input
          type="datetime-local"
          value={newDate}
          onChange={(e) => setNewDate(e.target.value)}
          className="flex-1 rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
        />
        <input
          type="text"
          value={newDescription}
          onChange={(e) => setNewDescription(e.target.value)}
          placeholder="Description de l'événement"
          className="flex-2 rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
        />
        <Button onClick={handleAddEvent} variant="primary" size="sm">
          <Plus className="w-4 h-4 mr-2" />
          Ajouter
        </Button>
      </div>

      <div className="space-y-4">
        {events.map((event) => (
          <div
            key={event.id}
            className="flex items-start gap-4 p-4 bg-gray-50 rounded-lg"
          >
            <div className="font-mono text-sm text-gray-600">
              {new Date(event.date).toLocaleString()}
            </div>
            <div className="flex-1">{event.description}</div>
          </div>
        ))}
      </div>
    </div>
  );
}