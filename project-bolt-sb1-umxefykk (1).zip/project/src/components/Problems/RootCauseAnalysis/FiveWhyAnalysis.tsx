import React, { useState } from 'react';
import { Button } from '../../common/Button/Button';

interface WhyLevel {
  id: string;
  question: string;
  answer: string;
}

export function FiveWhyAnalysis() {
  const [levels, setLevels] = useState<WhyLevel[]>([
    { id: '1', question: 'Pourquoi le problème est-il survenu ?', answer: '' }
  ]);

  const addLevel = () => {
    if (levels.length < 5) {
      setLevels([
        ...levels,
        {
          id: (levels.length + 1).toString(),
          question: `Pourquoi ? (${levels.length + 1})`,
          answer: ''
        }
      ]);
    }
  };

  const updateAnswer = (id: string, answer: string) => {
    setLevels(levels.map(level => 
      level.id === id ? { ...level, answer } : level
    ));
  };

  return (
    <div className="space-y-4">
      {levels.map((level, index) => (
        <div key={level.id} className="bg-gray-50 p-4 rounded-lg">
          <div className="font-semibold mb-2">{level.question}</div>
          <textarea
            value={level.answer}
            onChange={(e) => updateAnswer(level.id, e.target.value)}
            className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            rows={2}
          />
        </div>
      ))}
      
      {levels.length < 5 && (
        <Button onClick={addLevel} variant="outline" className="w-full">
          Ajouter un niveau
        </Button>
      )}
    </div>
  );
}