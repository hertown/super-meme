import React, { useState } from 'react';
import { IshikawaDiagram } from './IshikawaDiagram';
import { FiveWhyAnalysis } from './FiveWhyAnalysis';
import { ParetoAnalysis } from './ParetoAnalysis';
import { Timeline } from './Timeline';
import { Button } from '../../common/Button/Button';

type AnalysisTool = 'ishikawa' | 'fiveWhy' | 'pareto';

export function RootCauseAnalysis() {
  const [activeTool, setActiveTool] = useState<AnalysisTool | null>(null);

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Analyse des Causes Racines</h2>
        
        <div className="flex space-x-4 mb-6">
          <Button
            variant={activeTool === 'ishikawa' ? 'primary' : 'outline'}
            onClick={() => setActiveTool('ishikawa')}
          >
            Diagramme d'Ishikawa
          </Button>
          <Button
            variant={activeTool === 'fiveWhy' ? 'primary' : 'outline'}
            onClick={() => setActiveTool('fiveWhy')}
          >
            5 Pourquoi
          </Button>
          <Button
            variant={activeTool === 'pareto' ? 'primary' : 'outline'}
            onClick={() => setActiveTool('pareto')}
          >
            Analyse Pareto
          </Button>
        </div>

        <div className="mb-8">
          {activeTool === 'ishikawa' && <IshikawaDiagram />}
          {activeTool === 'fiveWhy' && <FiveWhyAnalysis />}
          {activeTool === 'pareto' && <ParetoAnalysis />}
        </div>

        <div className="border-t pt-6">
          <h3 className="text-lg font-semibold mb-4">Chronologie des événements</h3>
          <Timeline />
        </div>
      </div>
    </div>
  );
}