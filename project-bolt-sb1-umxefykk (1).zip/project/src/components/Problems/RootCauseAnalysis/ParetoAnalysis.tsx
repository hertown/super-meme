import React from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  Line,
  ComposedChart,
  ResponsiveContainer
} from 'recharts';

const data = [
  { name: 'Cause A', count: 35, cumulative: 35 },
  { name: 'Cause B', count: 25, cumulative: 60 },
  { name: 'Cause C', count: 20, cumulative: 80 },
  { name: 'Cause D', count: 15, cumulative: 95 },
  { name: 'Cause E', count: 5, cumulative: 100 }
];

export function ParetoAnalysis() {
  return (
    <div className="h-[400px]">
      <ResponsiveContainer width="100%" height="100%">
        <ComposedChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="name" />
          <YAxis yAxisId="left" />
          <YAxis yAxisId="right" orientation="right" />
          <Tooltip />
          <Legend />
          <Bar yAxisId="left" dataKey="count" fill="#3B82F6" name="Occurrences" />
          <Line
            yAxisId="right"
            type="monotone"
            dataKey="cumulative"
            stroke="#EF4444"
            name="Cumul %"
          />
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  );
}