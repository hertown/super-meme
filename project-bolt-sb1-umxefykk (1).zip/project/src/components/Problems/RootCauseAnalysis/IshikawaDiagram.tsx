import React, { useState } from 'react';
import { Plus } from 'lucide-react';
import { Button } from '../../common/Button/Button';

interface Category {
  name: string;
  causes: string[];
}

export function IshikawaDiagram() {
  const [categories, setCategories] = useState<Category[]>([
    { name: 'Machine', causes: [] },
    { name: 'Méthode', causes: [] },
    { name: 'Main d\'œuvre', causes: [] },
    { name: 'Matière', causes: [] },
    { name: 'Milieu', causes: [] },
    { name: 'Mesure', causes: [] }
  ]);

  const addCause = (categoryIndex: number, cause: string) => {
    const newCategories = [...categories];
    newCategories[categoryIndex].causes.push(cause);
    setCategories(newCategories);
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-6">
        {categories.map((category, index) => (
          <div key={index} className="bg-gray-50 p-4 rounded-lg">
            <h4 className="font-semibold mb-3">{category.name}</h4>
            <div className="space-y-2">
              {category.causes.map((cause, causeIndex) => (
                <div key={causeIndex} className="bg-white p-2 rounded">
                  {cause}
                </div>
              ))}
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Nouvelle cause"
                  className="flex-1 rounded-md border-gray-300 text-sm"
                  onKeyPress={(e) => {
                    if (e.key === 'Enter') {
                      const input = e.target as HTMLInputElement;
                      addCause(index, input.value);
                      input.value = '';
                    }
                  }}
                />
                <Button variant="outline" size="sm">
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}