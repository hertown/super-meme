export interface IshikawaCause {
  id: string;
  label: string;
}

export interface IshikawaCategory {
  name: string;
  causes: IshikawaCause[];
}

export const ishikawaCauses: IshikawaCategory[] = [
  {
    name: "Main d'œuvre",
    causes: [
      { id: 'mo1', label: 'Formation insuffisante' },
      { id: 'mo2', label: "Manque d'expérience" },
      { id: 'mo3', label: 'Fatigue' },
      { id: 'mo4', label: 'Stress' },
      { id: 'mo5', label: 'Communication défaillante' },
      { id: 'mo6', label: 'Rotation du personnel' }
    ]
  },
  {
    name: 'Méthodes',
    causes: [
      { id: 'me1', label: 'Procédures obsolètes' },
      { id: 'me2', label: 'Manque de documentation' },
      { id: 'me3', label: 'Process non standardisé' },
      { id: 'me4', label: 'Mauvaise planification' },
      { id: 'me5', label: 'Contrôle qualité insuffisant' },
      { id: 'me6', label: 'Protocoles inadaptés' }
    ]
  },
  {
    name: 'Matériel',
    causes: [
      { id: 'ma1', label: 'Équipement obsolète' },
      { id: 'ma2', label: 'Pannes fréquentes' },
      { id: 'ma3', label: 'Maintenance insuffisante' },
      { id: 'ma4', label: 'Configuration incorrecte' },
      { id: 'ma5', label: 'Capacité insuffisante' },
      { id: 'ma6', label: 'Incompatibilité système' }
    ]
  },
  {
    name: 'Milieu',
    causes: [
      { id: 'mi1', label: 'Conditions environnementales' },
      { id: 'mi2', label: 'Espace de travail inadapté' },
      { id: 'mi3', label: 'Infrastructure réseau' },
      { id: 'mi4', label: 'Sécurité physique' },
      { id: 'mi5', label: 'Interférences externes' },
      { id: 'mi6', label: 'Organisation spatiale' }
    ]
  },
  {
    name: 'Management',
    causes: [
      { id: 'mg1', label: 'Objectifs peu clairs' },
      { id: 'mg2', label: 'Manque de leadership' },
      { id: 'mg3', label: 'Communication inefficace' },
      { id: 'mg4', label: 'Ressources insuffisantes' },
      { id: 'mg5', label: 'Prise de décision lente' },
      { id: 'mg6', label: 'Suivi inadéquat' }
    ]
  },
  {
    name: 'Mesure',
    causes: [
      { id: 'ms1', label: 'Indicateurs inadaptés' },
      { id: 'ms2', label: 'Données imprécises' },
      { id: 'ms3', label: 'Manque de métriques' },
      { id: 'ms4', label: 'Outils de mesure défectueux' },
      { id: 'ms5', label: 'Fréquence inadéquate' },
      { id: 'ms6', label: 'Analyse insuffisante' }
    ]
  }
];