import React, { useState } from 'react';
import { Plus, ChevronDown } from 'lucide-react';
import { IshikawaCategory, IshikawaCause } from './IshikawaCauses';

interface IshikawaCategoryProps {
  category: IshikawaCategory;
  selectedCauses: IshikawaCause[];
  onAddCause: (cause: IshikawaCause) => void;
}

export function IshikawaCategoryComponent({ 
  category, 
  selectedCauses,
  onAddCause 
}: IshikawaCategoryProps) {
  const [showDropdown, setShowDropdown] = useState(false);

  const handleClickOutside = (e: MouseEvent) => {
    if (!(e.target as Element).closest('.cause-dropdown')) {
      setShowDropdown(false);
    }
  };

  React.useEffect(() => {
    if (showDropdown) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [showDropdown]);

  return (
    <div className="bg-white rounded-lg shadow p-4">
      <h4 className="font-semibold text-lg mb-3 text-blue-900">{category.name}</h4>
      
      <div className="space-y-2">
        {selectedCauses.map((cause) => (
          <div 
            key={cause.id}
            className="bg-blue-50 p-2 rounded-md text-blue-800 border border-blue-100"
          >
            {cause.label}
          </div>
        ))}

        <div className="relative cause-dropdown">
          <button
            onClick={() => setShowDropdown(!showDropdown)}
            className="w-full flex items-center justify-between px-3 py-2 text-sm 
                     border border-gray-300 rounded-md hover:bg-gray-50 
                     focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <span className="flex items-center">
              <Plus className="w-4 h-4 mr-2" />
              Ajouter une cause
            </span>
            <ChevronDown className={`w-4 h-4 transition-transform duration-200 ${showDropdown ? 'transform rotate-180' : ''}`} />
          </button>

          {showDropdown && (
            <div className="absolute z-10 w-full mt-1 bg-white rounded-md shadow-lg 
                          border border-gray-200 max-h-48 overflow-y-auto">
              {category.causes
                .filter(cause => !selectedCauses.some(sc => sc.id === cause.id))
                .map(cause => (
                  <button
                    key={cause.id}
                    onClick={() => {
                      onAddCause(cause);
                      setShowDropdown(false);
                    }}
                    className="w-full text-left px-4 py-2 text-sm text-gray-700 
                             hover:bg-blue-50 hover:text-blue-900 transition-colors duration-150"
                  >
                    {cause.label}
                  </button>
                ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}