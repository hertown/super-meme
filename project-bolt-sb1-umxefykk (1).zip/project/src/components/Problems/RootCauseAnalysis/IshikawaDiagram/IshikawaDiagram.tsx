import React, { useState } from 'react';
import { IshikawaCategoryComponent } from './IshikawaCategory';
import { ishikawaCauses, IshikawaCause } from './IshikawaCauses';
import { Button } from '../../../common/Button/Button';
import { Wand2 } from 'lucide-react';

interface SelectedCauses {
  [categoryName: string]: IshikawaCause[];
}

export function IshikawaDiagram() {
  const [selectedCauses, setSelectedCauses] = useState<SelectedCauses>(
    Object.fromEntries(ishikawaCauses.map(cat => [cat.name, []]))
  );

  const handleAddCause = (categoryName: string, cause: IshikawaCause) => {
    setSelectedCauses(prev => ({
      ...prev,
      [categoryName]: [...prev[categoryName], cause]
    }));
  };

  const handleAutoFill = () => {
    // Sélectionne automatiquement les causes les plus pertinentes pour chaque catégorie
    const autoFilledCauses: SelectedCauses = {};
    
    ishikawaCauses.forEach(category => {
      // Sélectionne aléatoirement 2-3 causes par catégorie
      const numberOfCauses = Math.floor(Math.random() * 2) + 2; // 2 ou 3 causes
      const shuffledCauses = [...category.causes].sort(() => Math.random() - 0.5);
      autoFilledCauses[category.name] = shuffledCauses.slice(0, numberOfCauses);
    });

    setSelectedCauses(autoFilledCauses);
  };

  const handleReset = () => {
    setSelectedCauses(
      Object.fromEntries(ishikawaCauses.map(cat => [cat.name, []]))
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-end space-x-4 mb-4">
        <Button
          variant="outline"
          size="sm"
          onClick={handleReset}
          className="text-red-600 hover:bg-red-50"
        >
          Réinitialiser
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={handleAutoFill}
          className="text-blue-600 hover:bg-blue-50"
        >
          <Wand2 className="w-4 h-4 mr-2" />
          Remplissage automatique
        </Button>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-3 gap-6">
        {ishikawaCauses.map((category) => (
          <IshikawaCategoryComponent
            key={category.name}
            category={category}
            selectedCauses={selectedCauses[category.name]}
            onAddCause={(cause) => handleAddCause(category.name, cause)}
          />
        ))}
      </div>
    </div>
  );
}