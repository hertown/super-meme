import React from 'react';
import { ProblemDistribution } from './Charts/ProblemDistribution';
import { ProblemImpact } from './Charts/ProblemImpact';

export function ProblemCharts() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <div className="bg-white rounded-lg shadow">
        <h3 className="text-lg font-semibold p-4 border-b">Distribution des problèmes</h3>
        <div className="p-4">
          <ProblemDistribution />
        </div>
      </div>
      
      <div className="bg-white rounded-lg shadow">
        <h3 className="text-lg font-semibold p-4 border-b">Impact des problèmes</h3>
        <div className="p-4">
          <ProblemImpact />
        </div>
      </div>
    </div>
  );
}