import React from 'react';
import { Activity, Clock, CheckCircle, Server } from 'lucide-react';
import { Card } from '../common/Card/Card';

const metrics = [
  {
    title: 'Incidents actifs',
    value: '24',
    icon: Activity,
    color: 'text-blue-500',
    bgColor: 'bg-blue-50'
  },
  {
    title: 'Temps moyen de résolution',
    value: '2h 15m',
    icon: Clock,
    color: 'text-indigo-500',
    bgColor: 'bg-indigo-50'
  },
  {
    title: 'Taux de résolution',
    value: '92%',
    icon: CheckCircle,
    color: 'text-green-500',
    bgColor: 'bg-green-50'
  },
  {
    title: 'Disponibilité du système',
    value: '99.9%',
    icon: Server,
    color: 'text-purple-500',
    bgColor: 'bg-purple-50'
  }
];

export function MetricsOverview() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {metrics.map((metric, index) => (
        <div
          key={index}
          className={`opacity-0 translate-y-4 animate-fade-in-up`}
          style={{
            animationDelay: `${index * 100}ms`,
            animationFillMode: 'forwards'
          }}
        >
          <Card className="relative overflow-hidden transition-transform duration-200 hover:scale-105">
            <div className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{metric.title}</p>
                  <p className="mt-2 text-3xl font-bold text-gray-900">{metric.value}</p>
                </div>
                <div className={`${metric.bgColor} p-3 rounded-lg`}>
                  <metric.icon className={`w-6 h-6 ${metric.color}`} />
                </div>
              </div>
            </div>
            <div className={`absolute bottom-0 left-0 right-0 h-1 ${metric.color.replace('text', 'bg')}`} />
          </Card>
        </div>
      ))}
    </div>
  );
}