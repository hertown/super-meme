import React from 'react';
import { AlertTriangle } from 'lucide-react';

export function AlertBanner() {
  return (
    <div className="bg-orange-500 text-white px-6 py-4 rounded-lg mb-8 shadow-lg animate-pulse">
      <div className="flex items-center space-x-3">
        <AlertTriangle className="h-6 w-6" />
        <p className="font-medium">Alerte: 5 incidents critiques en attente de résolution</p>
      </div>
    </div>
  );
}