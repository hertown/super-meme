import React from 'react';
import { BarChart3, AlertCircle, CheckCircle2, Clock } from 'lucide-react';
import MetricCard from './MetricCard';
import { DashboardMetrics } from '../../types';

interface MetricsGridProps {
  metrics: DashboardMetrics;
}

export default function MetricsGrid({ metrics }: MetricsGridProps) {
  const metricCards = [
    {
      title: 'Total Incidents',
      value: metrics.totalIncidents,
      Icon: BarChart3,
      iconColor: 'text-blue-500'
    },
    {
      title: 'Open Incidents',
      value: metrics.openIncidents,
      Icon: AlertCircle,
      iconColor: 'text-yellow-500'
    },
    {
      title: 'Critical Incidents',
      value: metrics.criticalIncidents,
      Icon: Clock,
      iconColor: 'text-red-500'
    },
    {
      title: 'Resolved Today',
      value: metrics.resolvedToday,
      Icon: CheckCircle2,
      iconColor: 'text-green-500'
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      {metricCards.map((card, index) => (
        <MetricCard key={index} {...card} />
      ))}
    </div>
  );
}