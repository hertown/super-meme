import React from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';

const data = [
  { day: 'Lun', critiques: 5, majeurs: 8, mineurs: 12 },
  { day: 'Mar', critiques: 7, majeurs: 10, mineurs: 15 },
  { day: 'Mer', critiques: 4, majeurs: 12, mineurs: 10 },
  { day: 'Jeu', critiques: 6, majeurs: 9, mineurs: 14 },
  { day: 'Ven', critiques: 8, majeurs: 7, mineurs: 11 },
  { day: 'Sam', critiques: 3, majeurs: 5, mineurs: 8 },
  { day: 'Dim', critiques: 4, majeurs: 6, mineurs: 9 },
];

export function IncidentTrendChart() {
  return (
    <ResponsiveContainer width="100%" height={300}>
      <LineChart data={data} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="day" />
        <YAxis />
        <Tooltip />
        <Legend />
        <Line
          type="monotone"
          dataKey="critiques"
          stroke="#EF4444"
          strokeWidth={2}
          dot={{ fill: '#EF4444' }}
        />
        <Line
          type="monotone"
          dataKey="majeurs"
          stroke="#F97316"
          strokeWidth={2}
          dot={{ fill: '#F97316' }}
        />
        <Line
          type="monotone"
          dataKey="mineurs"
          stroke="#22C55E"
          strokeWidth={2}
          dot={{ fill: '#22C55E' }}
        />
      </LineChart>
    </ResponsiveContainer>
  );
}