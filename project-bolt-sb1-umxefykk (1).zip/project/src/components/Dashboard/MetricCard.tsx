import React from 'react';
import { LucideIcon } from 'lucide-react';

interface MetricCardProps {
  title: string;
  value: number;
  Icon: LucideIcon;
  iconColor: string;
}

export default function MetricCard({ title, value, Icon, iconColor }: MetricCardProps) {
  return (
    <div className="bg-white rounded-lg shadow p-4">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-gray-500">{title}</p>
          <p className="text-2xl font-bold">{value}</p>
        </div>
        <Icon className={iconColor} size={24} />
      </div>
    </div>
  );
}