import React from 'react';
import DashboardHeader from './DashboardHeader';
import MetricsGrid from './MetricsGrid';
import IncidentsTable from '../Incidents/IncidentsTable';

export default function Dashboard() {
  return (
    <div className="p-6">
      <DashboardHeader title="Incident Management Dashboard" />
      <MetricsGrid />
      <IncidentsTable />
    </div>
  );
}