import React from 'react';
import { Card } from '../common/Card/Card';
import { CardHeader } from '../common/Card/CardHeader';
import { IncidentPriorityChart } from './Charts/IncidentPriorityChart';
import { IncidentTrendChart } from './Charts/IncidentTrendChart';

interface StatItemProps {
  label: string;
  value: string | number;
  color: string;
}

function StatItem({ label, value, color }: StatItemProps) {
  return (
    <div className="flex items-center justify-between p-3 border-b last:border-b-0">
      <span className="text-gray-600">{label}</span>
      <span className={`font-semibold ${color}`}>{value}</span>
    </div>
  );
}

export function IncidentStats() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
      <Card>
        <CardHeader title="Statuts des incidents par criticité" />
        <div className="p-4">
          <IncidentPriorityChart />
          <div className="mt-4 border-t">
            <StatItem label="Critique" value="5" color="text-red-600" />
            <StatItem label="Majeur" value="8" color="text-orange-600" />
            <StatItem label="Mineur" value="12" color="text-green-600" />
          </div>
        </div>
      </Card>
      
      <Card className="lg:col-span-2">
        <CardHeader title="Tendance des incidents" />
        <div className="p-4">
          <IncidentTrendChart />
        </div>
      </Card>
    </div>
  );
}