import React from 'react';
import { Incident } from '../../types';
import StatusBadge from '../common/StatusBadge';
import PriorityBadge from '../common/PriorityBadge';
import { MoreVertical } from 'lucide-react';

interface TableRowProps {
  incident: Incident;
}

export default function TableRow({ incident }: TableRowProps) {
  return (
    <tr className="border-t hover:bg-gray-50">
      <td className="py-3 pl-4">{incident.id}</td>
      <td className="py-3">
        <div>
          <div className="font-medium text-gray-900">{incident.title}</div>
          <div className="text-sm text-gray-500">{incident.description}</div>
        </div>
      </td>
      <td className="py-3">
        <PriorityBadge priority={incident.priority} />
      </td>
      <td className="py-3">
        <StatusBadge status={incident.status} />
      </td>
      <td className="py-3">
        <div className="flex items-center">
          <div className="h-8 w-8 rounded-full bg-gray-200 flex items-center justify-center">
            {incident.assignee.charAt(0)}
          </div>
          <span className="ml-2">{incident.assignee}</span>
        </div>
      </td>
      <td className="py-3 pr-4">
        <button className="text-gray-400 hover:text-gray-600">
          <MoreVertical size={20} />
        </button>
      </td>
    </tr>
  );
}