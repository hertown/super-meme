import React from 'react';
import { IncidentCard } from './IncidentCard/IncidentCard';
import { mockIncidents } from '../../data/mockData';

export function IncidentsList() {
  return (
    <div className="grid grid-cols-1 gap-6">
      {mockIncidents.map(incident => (
        <IncidentCard key={incident.id} incident={incident} />
      ))}
    </div>
  );
}