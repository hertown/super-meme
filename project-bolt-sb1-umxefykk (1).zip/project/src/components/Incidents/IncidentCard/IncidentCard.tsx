import React from 'react';
import { Incident } from '../../../types';
import { Card } from '../../common/Card/Card';
import { CardHeader } from '../../common/Card/CardHeader';
import { IncidentDetails } from './IncidentDetails';
import { IncidentActions } from './IncidentActions';

interface IncidentCardProps {
  incident: Incident;
}

export function IncidentCard({ incident }: IncidentCardProps) {
  return (
    <Card>
      <CardHeader 
        title={incident.title}
        description={`ID: ${incident.id}`}
        action={<IncidentActions incident={incident} />}
      />
      <IncidentDetails incident={incident} />
    </Card>
  );
}