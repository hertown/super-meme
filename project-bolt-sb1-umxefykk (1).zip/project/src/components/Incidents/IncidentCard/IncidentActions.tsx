import React from 'react';
import { Incident } from '../../../types';
import { Button } from '../../common/Button/Button';
import { MoreVertical } from 'lucide-react';

interface IncidentActionsProps {
  incident: Incident;
}

export function IncidentActions({ incident }: IncidentActionsProps) {
  return (
    <div className="flex items-center space-x-2">
      <Button
        variant="outline"
        size="sm"
        onClick={() => console.log('Edit incident:', incident.id)}
      >
        Edit
      </Button>
      <Button
        variant="outline"
        size="sm"
        className="p-2"
      >
        <MoreVertical size={16} />
      </Button>
    </div>
  );
}