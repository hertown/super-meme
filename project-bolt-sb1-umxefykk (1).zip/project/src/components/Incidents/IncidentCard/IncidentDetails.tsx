import React from 'react';
import { Incident } from '../../../types';
import { Badge } from '../../common/Badge/Badge';
import { formatDateTime } from '../../../utils/date';

interface IncidentDetailsProps {
  incident: Incident;
}

export function IncidentDetails({ incident }: IncidentDetailsProps) {
  return (
    <div className="p-4">
      <div className="space-y-4">
        <div>
          <p className="text-sm text-gray-500">Description</p>
          <p className="mt-1">{incident.description}</p>
        </div>
        
        <div className="flex flex-wrap gap-4">
          <div>
            <p className="text-sm text-gray-500">Status</p>
            <Badge 
              label={incident.status}
              variant={incident.status === 'resolved' ? 'success' : 'warning'}
            />
          </div>
          
          <div>
            <p className="text-sm text-gray-500">Priority</p>
            <Badge 
              label={incident.priority}
              variant={incident.priority === 'critical' ? 'error' : 'info'}
            />
          </div>
          
          <div>
            <p className="text-sm text-gray-500">Assignee</p>
            <p className="mt-1 font-medium">{incident.assignee}</p>
          </div>
          
          <div>
            <p className="text-sm text-gray-500">Created</p>
            <p className="mt-1">{formatDateTime(incident.createdAt)}</p>
          </div>
        </div>
      </div>
    </div>
  );
}