import React from 'react';
import { FilterOptions, IncidentStatus, IncidentPriority } from '../../types';

interface IncidentFiltersProps {
  filters: FilterOptions;
  onFilterChange: (filters: FilterOptions) => void;
}

export default function IncidentFilters({ filters, onFilterChange }: IncidentFiltersProps) {
  const statuses: IncidentStatus[] = ['open', 'in-progress', 'resolved', 'closed'];
  const priorities: IncidentPriority[] = ['low', 'medium', 'high', 'critical'];

  const handleStatusChange = (status: IncidentStatus) => {
    const currentStatuses = filters.status || [];
    const newStatuses = currentStatuses.includes(status)
      ? currentStatuses.filter(s => s !== status)
      : [...currentStatuses, status];
    
    onFilterChange({ ...filters, status: newStatuses });
  };

  const handlePriorityChange = (priority: IncidentPriority) => {
    const currentPriorities = filters.priority || [];
    const newPriorities = currentPriorities.includes(priority)
      ? currentPriorities.filter(p => p !== priority)
      : [...currentPriorities, priority];
    
    onFilterChange({ ...filters, priority: newPriorities });
  };

  return (
    <div className="p-4 bg-white border-b">
      <div className="space-y-4">
        <div>
          <h3 className="text-sm font-medium text-gray-700 mb-2">Status</h3>
          <div className="flex flex-wrap gap-2">
            {statuses.map(status => (
              <button
                key={status}
                onClick={() => handleStatusChange(status)}
                className={`px-3 py-1 rounded-full text-xs font-medium ${
                  filters.status?.includes(status)
                    ? 'bg-blue-100 text-blue-800'
                    : 'bg-gray-100 text-gray-800'
                }`}
              >
                {status}
              </button>
            ))}
          </div>
        </div>

        <div>
          <h3 className="text-sm font-medium text-gray-700 mb-2">Priority</h3>
          <div className="flex flex-wrap gap-2">
            {priorities.map(priority => (
              <button
                key={priority}
                onClick={() => handlePriorityChange(priority)}
                className={`px-3 py-1 rounded-full text-xs font-medium ${
                  filters.priority?.includes(priority)
                    ? 'bg-blue-100 text-blue-800'
                    : 'bg-gray-100 text-gray-800'
                }`}
              >
                {priority}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}