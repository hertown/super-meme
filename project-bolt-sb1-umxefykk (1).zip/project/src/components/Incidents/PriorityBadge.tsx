import React from 'react';
import { IncidentPriority } from '../../types';
import { getPriorityStyles } from '../../utils/statusStyles';

interface PriorityBadgeProps {
  priority: IncidentPriority;
}

export default function PriorityBadge({ priority }: PriorityBadgeProps) {
  const priorityStyle = getPriorityStyles(priority);
  
  return (
    <span className={`px-2 py-1 rounded-full text-xs ${priorityStyle}`}>
      {priority}
    </span>
  );
}