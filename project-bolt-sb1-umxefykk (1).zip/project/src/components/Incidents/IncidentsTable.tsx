import React from 'react';
import { Incident } from '../../types';
import TableHeader from './TableHeader';
import TableColumns from './TableColumns';
import TableRow from './TableRow';
import IncidentFilters from './IncidentFilters';
import { useIncidents } from '../../hooks/useIncidents';

export default function IncidentsTable() {
  const {
    incidents,
    filters,
    setFilters,
    sortField,
    setSortField,
    sortDirection,
    setSortDirection,
  } = useIncidents();

  return (
    <div className="bg-white rounded-lg shadow">
      <TableHeader />
      <IncidentFilters filters={filters} onFilterChange={setFilters} />
      <div className="p-4 overflow-x-auto">
        <table className="w-full min-w-[640px]">
          <thead>
            <TableColumns
              sortField={sortField}
              sortDirection={sortDirection}
              onSort={(field) => {
                if (field === sortField) {
                  setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
                } else {
                  setSortField(field);
                  setSortDirection('asc');
                }
              }}
            />
          </thead>
          <tbody>
            {incidents.map(incident => (
              <TableRow key={incident.id} incident={incident} />
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}