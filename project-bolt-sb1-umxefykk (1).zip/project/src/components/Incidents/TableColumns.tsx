import React from 'react';
import { ChevronUp, ChevronDown } from 'lucide-react';
import { Incident, SortDirection } from '../../types';

interface TableColumnsProps {
  sortField: keyof Incident;
  sortDirection: SortDirection;
  onSort: (field: keyof Incident) => void;
}

interface Column {
  field: keyof Incident;
  label: string;
  sortable: boolean;
}

export default function TableColumns({ sortField, sortDirection, onSort }: TableColumnsProps) {
  const columns: Column[] = [
    { field: 'id', label: 'ID', sortable: true },
    { field: 'title', label: 'Title', sortable: true },
    { field: 'priority', label: 'Priority', sortable: true },
    { field: 'status', label: 'Status', sortable: true },
    { field: 'assignee', label: 'Assignee', sortable: true },
  ];

  return (
    <tr className="text-left text-gray-500">
      {columns.map(({ field, label, sortable }) => (
        <th
          key={field}
          className={`pb-3 ${field === 'id' ? 'pl-4' : ''} ${
            sortable ? 'cursor-pointer hover:text-gray-700' : ''
          }`}
          onClick={() => sortable && onSort(field)}
        >
          <div className="flex items-center space-x-1">
            <span>{label}</span>
            {sortable && field === sortField && (
              {
                'asc': <ChevronUp size={16} />,
                'desc': <ChevronDown size={16} />
              }[sortDirection]
            )}
          </div>
        </th>
      ))}
      <th className="pb-3 pr-4">Actions</th>
    </tr>
  );
}