import React from 'react';
import { IncidentStatus } from '../../types';
import { getStatusStyles } from '../../utils/statusStyles';

interface StatusBadgeProps {
  status: IncidentStatus;
}

export default function StatusBadge({ status }: StatusBadgeProps) {
  const statusStyle = getStatusStyles(status);
  
  return (
    <span className={`px-2 py-1 rounded-full text-xs ${statusStyle}`}>
      {status}
    </span>
  );
}