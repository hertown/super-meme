import React from 'react';

export default function TableHeader() {
  return (
    <div className="p-4 border-b flex justify-between items-center">
      <div>
        <h2 className="text-lg font-semibold text-gray-900">Recent Incidents</h2>
        <p className="mt-1 text-sm text-gray-500">
          Track and manage ongoing incidents
        </p>
      </div>
      <div className="flex space-x-2">
        <button className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50">
          Export
        </button>
        <button className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700">
          New Incident
        </button>
      </div>
    </div>
  );
}