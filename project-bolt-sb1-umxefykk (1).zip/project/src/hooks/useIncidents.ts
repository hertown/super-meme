import { useState, useMemo } from 'react';
import { Incident, FilterOptions, SortDirection } from '../types';
import { filterIncidents } from '../utils/filters';
import { sortIncidents } from '../utils/sort';
import { mockIncidents } from '../data/mockData';

export function useIncidents() {
  const [filters, setFilters] = useState<FilterOptions>({});
  const [sortField, setSortField] = useState<keyof Incident>('createdAt');
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc');

  const filteredIncidents = useMemo(() => {
    return filterIncidents(mockIncidents, filters);
  }, [filters]);

  const sortedIncidents = useMemo(() => {
    return sortIncidents(filteredIncidents, sortField, sortDirection);
  }, [filteredIncidents, sortField, sortDirection]);

  return {
    incidents: sortedIncidents,
    filters,
    setFilters,
    sortField,
    setSortField,
    sortDirection,
    setSortDirection,
  };
}