import { useState } from 'react';
import { Language, translations } from '../i18n/translations';

export function useLanguage() {
  const [language, setLanguage] = useState<Language>('fr');

  const t = (key: string) => {
    const keys = key.split('.');
    let value: any = translations[language];
    
    for (const k of keys) {
      value = value[k];
    }
    
    return value || key;
  };

  return {
    language,
    setLanguage,
    t
  };
}