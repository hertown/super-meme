import { useState } from 'react';

interface Filters {
  category: string;
  status: string;
  priority: string;
}

export function useFilters() {
  const [filters, setFilters] = useState<Filters>({
    category: 'all',
    status: 'all',
    priority: 'all'
  });

  const updateFilter = (key: keyof Filters, value: string) => {
    setFilters(prev => ({
      ...prev,
      [key]: value
    }));
  };

  return {
    filters,
    updateFilter
  };
}