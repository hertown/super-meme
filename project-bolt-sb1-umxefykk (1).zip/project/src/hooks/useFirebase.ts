import { useState, useEffect } from 'react';
import { firebaseAuth } from '../services/firebase/auth';
import { firestoreService } from '../services/firebase/firestore';
import { storageService } from '../services/firebase/storage';
import { Incident, Problem } from '../types';

export function useFirebase() {
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [problems, setProblems] = useState<Problem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const [incidentsData, problemsData] = await Promise.all([
        firestoreService.getIncidents(),
        firestoreService.getProblems()
      ]);
      setIncidents(incidentsData);
      setProblems(problemsData);
      setError(null);
    } catch (err: any) {
      setError(err.message);
      console.error('Error loading data:', err);
    } finally {
      setLoading(false);
    }
  };

  return {
    incidents,
    problems,
    loading,
    error,
    refresh: loadData
  };
}