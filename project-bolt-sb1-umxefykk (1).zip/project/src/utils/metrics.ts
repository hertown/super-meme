import { Incident, DashboardMetrics } from '../types';

function countIncidentsByStatus(incidents: Incident[], status: string): number {
  return incidents.filter(i => i.status === status).length;
}

function countIncidentsByPriority(incidents: Incident[], priority: string): number {
  return incidents.filter(i => i.priority === priority).length;
}

function calculateAverageResolutionTime(incidents: Incident[]): string {
  const resolvedIncidents = incidents.filter(i => i.status === 'resolved');
  if (resolvedIncidents.length === 0) return 'N/A';

  const totalTime = resolvedIncidents.reduce((acc, incident) => {
    const created = new Date(incident.createdAt);
    const resolved = new Date(incident.updatedAt);
    return acc + (resolved.getTime() - created.getTime());
  }, 0);

  const averageHours = Math.round(totalTime / (resolvedIncidents.length * 3600000));
  return `${averageHours}h`;
}

function getResolvedTodayCount(incidents: Incident[]): number {
  const now = new Date();
  const startOfDay = new Date(now.setHours(0, 0, 0, 0));
  
  return incidents.filter(i => 
    i.status === 'resolved' && 
    new Date(i.updatedAt) >= startOfDay
  ).length;
}

export function calculateMetrics(incidents: Incident[]): DashboardMetrics {
  return {
    totalIncidents: incidents.length,
    openIncidents: countIncidentsByStatus(incidents, 'open'),
    criticalIncidents: countIncidentsByPriority(incidents, 'critical'),
    resolvedToday: getResolvedTodayCount(incidents),
    averageResolutionTime: calculateAverageResolutionTime(incidents)
  };
}