import { Incident, SortDirection } from '../types';

export function sortIncidents(
  incidents: Incident[],
  field: keyof Incident,
  direction: SortDirection
): Incident[] {
  return [...incidents].sort((a, b) => {
    const aValue = a[field];
    const bValue = b[field];
    const multiplier = direction === 'asc' ? 1 : -1;
    
    if (typeof aValue === 'string' && typeof bValue === 'string') {
      return multiplier * aValue.localeCompare(bValue);
    }
    
    if (aValue instanceof Date && bValue instanceof Date) {
      return multiplier * (aValue.getTime() - bValue.getTime());
    }
    
    return 0;
  });
}