import { Incident, FilterOptions } from '../types';

export function filterIncidents(incidents: Incident[], filters: FilterOptions): Incident[] {
  return incidents.filter(incident => {
    if (filters.status && !filters.status.includes(incident.status)) {
      return false;
    }
    
    if (filters.priority && !filters.priority.includes(incident.priority)) {
      return false;
    }
    
    if (filters.assignee && !filters.assignee.includes(incident.assignee)) {
      return false;
    }
    
    if (filters.dateRange) {
      const incidentDate = new Date(incident.createdAt);
      const start = new Date(filters.dateRange.start);
      const end = new Date(filters.dateRange.end);
      if (incidentDate < start || incidentDate > end) {
        return false;
      }
    }
    
    return true;
  });
}