import { IncidentStatus, IncidentPriority } from '../types';

export function getStatusStyles(status: IncidentStatus): string {
  const styles = {
    'open': 'bg-yellow-100 text-yellow-800',
    'in-progress': 'bg-blue-100 text-blue-800',
    'resolved': 'bg-green-100 text-green-800',
    'closed': 'bg-gray-100 text-gray-800'
  };
  
  return styles[status];
}

export function getPriorityStyles(priority: IncidentPriority): string {
  const styles = {
    'critical': 'bg-red-100 text-red-800',
    'high': 'bg-orange-100 text-orange-800',
    'medium': 'bg-blue-100 text-blue-800',
    'low': 'bg-gray-100 text-gray-800'
  };
  
  return styles[priority];
}