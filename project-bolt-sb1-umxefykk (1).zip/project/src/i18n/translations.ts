export type Language = 'fr' | 'en';

export const translations = {
  fr: {
    welcome: 'Bienvenue sur Dashboard Manager ITSM Analytics',
    login: {
      subtitle: 'Connectez-vous pour accéder à votre espace',
      email: 'Email',
      password: 'Mot de passe',
      rememberMe: 'Se souvenir de moi',
      forgotPassword: 'Mot de passe oublié?',
      loginButton: 'Se connecter',
      createAccount: 'Créer un compte'
    },
    register: {
      title: 'Créez votre compte',
      subtitle: 'Rejoignez-nous pour gérer vos services IT'
    }
  },
  en: {
    welcome: 'Welcome to Dashboard Manager ITSM Analytics',
    login: {
      subtitle: 'Sign in to access your workspace',
      email: 'Email',
      password: 'Password',
      rememberMe: 'Remember me',
      forgotPassword: 'Forgot password?',
      loginButton: 'Sign in',
      createAccount: 'Create account'
    },
    register: {
      title: 'Create your account',
      subtitle: 'Join us to manage your IT services'
    }
  }
};