import { 
  collection,
  doc,
  getDoc,
  getDocs,
  addDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  Timestamp,
  DocumentData
} from 'firebase/firestore';
import { db } from '../../config/firebase';
import { Incident, Problem } from '../../types';

export const firestoreService = {
  // Incidents
  async getIncidents() {
    try {
      const incidentsRef = collection(db, 'incidents');
      const q = query(incidentsRef, orderBy('createdAt', 'desc'));
      const snapshot = await getDocs(q);
      return snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Incident[];
    } catch (error: any) {
      throw new Error(error.message);
    }
  },

  async addIncident(incident: Omit<Incident, 'id'>) {
    try {
      const docRef = await addDoc(collection(db, 'incidents'), {
        ...incident,
        createdAt: Timestamp.now(),
        updatedAt: Timestamp.now()
      });
      return docRef.id;
    } catch (error: any) {
      throw new Error(error.message);
    }
  },

  // Problems
  async getProblems() {
    try {
      const problemsRef = collection(db, 'problems');
      const q = query(problemsRef, orderBy('createdAt', 'desc'));
      const snapshot = await getDocs(q);
      return snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Problem[];
    } catch (error: any) {
      throw new Error(error.message);
    }
  },

  async addProblem(problem: Omit<Problem, 'id'>) {
    try {
      const docRef = await addDoc(collection(db, 'problems'), {
        ...problem,
        createdAt: Timestamp.now(),
        updatedAt: Timestamp.now()
      });
      return docRef.id;
    } catch (error: any) {
      throw new Error(error.message);
    }
  },

  // Generic CRUD operations
  async getDocument(collectionName: string, id: string) {
    try {
      const docRef = doc(db, collectionName, id);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        return { id: docSnap.id, ...docSnap.data() };
      }
      return null;
    } catch (error: any) {
      throw new Error(error.message);
    }
  },

  async updateDocument(collectionName: string, id: string, data: Partial<DocumentData>) {
    try {
      const docRef = doc(db, collectionName, id);
      await updateDoc(docRef, {
        ...data,
        updatedAt: Timestamp.now()
      });
    } catch (error: any) {
      throw new Error(error.message);
    }
  },

  async deleteDocument(collectionName: string, id: string) {
    try {
      const docRef = doc(db, collectionName, id);
      await deleteDoc(docRef);
    } catch (error: any) {
      throw new Error(error.message);
    }
  }
};