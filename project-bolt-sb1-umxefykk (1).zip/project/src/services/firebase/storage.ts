import { 
  ref,
  uploadBytes,
  getDownloadURL,
  deleteObject,
  listAll
} from 'firebase/storage';
import { storage } from '../../config/firebase';

export const storageService = {
  async uploadFile(file: File, path: string) {
    try {
      const storageRef = ref(storage, path);
      const snapshot = await uploadBytes(storageRef, file);
      const downloadURL = await getDownloadURL(snapshot.ref);
      return downloadURL;
    } catch (error: any) {
      throw new Error(error.message);
    }
  },

  async deleteFile(path: string) {
    try {
      const storageRef = ref(storage, path);
      await deleteObject(storageRef);
    } catch (error: any) {
      throw new Error(error.message);
    }
  },

  async listFiles(path: string) {
    try {
      const storageRef = ref(storage, path);
      const res = await listAll(storageRef);
      const urls = await Promise.all(
        res.items.map(itemRef => getDownloadURL(itemRef))
      );
      return urls;
    } catch (error: any) {
      throw new Error(error.message);
    }
  }
};