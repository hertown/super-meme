import React from 'react';
import { ProblemMetrics } from '../components/Problems/ProblemMetrics';
import { ProblemDistribution } from '../components/Problems/Charts/ProblemDistribution';
import { ProblemImpact } from '../components/Problems/Charts/ProblemImpact';
import { ActiveProblemsTable } from '../components/Problems/ActiveProblemsTable';
import { RootCauseAnalysis } from '../components/Problems/RootCauseAnalysis/RootCauseAnalysis';

export function ProblemsPage() {
  return (
    <div className="space-y-6">
      <ProblemMetrics />
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <div className="bg-white rounded-lg shadow">
          <h3 className="text-lg font-semibold p-4 border-b">Distribution des problèmes</h3>
          <div className="p-4">
            <ProblemDistribution />
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow">
          <h3 className="text-lg font-semibold p-4 border-b">Impact des problèmes</h3>
          <div className="p-4">
            <ProblemImpact />
          </div>
        </div>
      </div>

      <ActiveProblemsTable />
      
      <RootCauseAnalysis />
    </div>
  );
}