export type IncidentStatus = 'open' | 'in-progress' | 'resolved' | 'closed';
export type IncidentPriority = 'low' | 'medium' | 'high' | 'critical';
export type SortDirection = 'asc' | 'desc';

export interface SLA {
  deadline: string;
  breached: boolean;
}

export interface Incident {
  id: string;
  title: string;
  description: string;
  status: IncidentStatus;
  priority: IncidentPriority;
  assignee: string;
  createdAt: string;
  updatedAt: string;
  sla?: SLA;
}

export interface DashboardMetrics {
  totalIncidents: number;
  openIncidents: number;
  resolvedToday: number;
  criticalIncidents: number;
  averageResolutionTime: string;
  slaBreachRate: number;
}

export interface FilterOptions {
  status?: IncidentStatus[];
  priority?: IncidentPriority[];
  assignee?: string[];
  dateRange?: {
    start: string;
    end: string;
  };
}