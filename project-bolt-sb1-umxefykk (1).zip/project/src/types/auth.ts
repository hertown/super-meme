export type UserRole = 'admin' | 'manager' | 'technician' | 'user';

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  organization: string;
  avatar?: string;
}

export interface UserCredentials {
  email: string;
  password: string;
}

export interface UserRegistration extends UserCredentials {
  name: string;
  role: UserRole;
  organization: string;
}

export interface AuthState {
  user: User | null;
  loading: boolean;
  error: string | null;
}