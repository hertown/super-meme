import React from 'react';
import { ProblemMetrics } from '../components/Problems/ProblemMetrics';
import { ProblemCharts } from '../components/Problems/ProblemCharts';
import { ActiveProblemsTable } from '../components/Problems/ActiveProblemsTable';
import { RootCauseAnalysis } from '../components/Problems/RootCauseAnalysis/RootCauseAnalysis';

export function ProblemsView() {
  return (
    <div className="space-y-6">
      <ProblemMetrics />
      <ProblemCharts />
      <ActiveProblemsTable />
      <RootCauseAnalysis />
    </div>
  );
}