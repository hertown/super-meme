import React from 'react';
import { AlertBanner } from '../components/Dashboard/AlertBanner';
import { MetricsOverview } from '../components/Dashboard/MetricsOverview';
import { IncidentStats } from '../components/Dashboard/IncidentStats';
import { IncidentsList } from '../components/Incidents/IncidentsList';

export function DashboardView() {
  return (
    <div className="space-y-6">
      <AlertBanner />
      <MetricsOverview />
      <IncidentStats />
      <IncidentsList />
    </div>
  );
}