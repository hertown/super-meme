import { Incident } from '../types';

export const mockIncidents: Incident[] = [
  {
    id: "INC-001",
    title: "Production Server Down",
    description: "Main production server is unresponsive",
    status: "open",
    priority: "critical",
    assignee: "John Doe",
    createdAt: new Date(Date.now() - 3600000).toISOString(),
    updatedAt: new Date().toISOString(),
    sla: {
      deadline: new Date(Date.now() + 3600000).toISOString(),
      breached: false
    }
  },
  {
    id: "INC-002",
    title: "Database Connection Issues",
    description: "Users reporting intermittent database connectivity",
    status: "in-progress",
    priority: "high",
    assignee: "Jane Smith",
    createdAt: new Date(Date.now() - 7200000).toISOString(),
    updatedAt: new Date().toISOString(),
    sla: {
      deadline: new Date(Date.now() + 7200000).toISOString(),
      breached: false
    }
  }
];